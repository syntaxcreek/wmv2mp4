(function () {
  'use strict';

  var FFmpeg = window.FFmpegWASM && window.FFmpegWASM.FFmpeg;
  var fetchFile = window.FFmpegUtil && window.FFmpegUtil.fetchFile;

  var $ = function (id) { return document.getElementById(id); };
  var drop = $('drop'), fileInput = $('file'), queueEl = $('queue');
  var queueHead = $('queueHead'), engineEl = $('engine');
  var convertBtn = $('convert'), clearBtn = $('clear');

  var items = [];        // { id, file, state, el, ... }
  var nextId = 1;
  var ffmpeg = null;
  var loading = null;
  var running = false;
  var cancelled = false;
  var currentItem = null;

  function fmtSize(n) {
    if (n >= 1073741824) return (n / 1073741824).toFixed(2) + ' GB';
    if (n >= 1048576) return (n / 1048576).toFixed(1) + ' MB';
    return Math.max(1, Math.round(n / 1024)) + ' KB';
  }

  function setEngine(text, isErr) {
    engineEl.textContent = text;
    engineEl.classList.toggle('err', !!isErr);
  }

  /* ---------- queue UI ---------- */

  function addFiles(list) {
    Array.prototype.forEach.call(list, function (file) {
      var ok = /\.(wmv|asf)$/i.test(file.name) || file.type === 'video/x-ms-wmv';
      var it = { id: nextId++, file: file, state: ok ? 'ready' : 'invalid', url: null };
      items.push(it);
      queueEl.appendChild(render(it));
      if (!ok) setMeta(it, 'Skipped. This is not a WMV or ASF file.', 'err');
    });
    refreshHead();
  }

  function render(it) {
    var li = document.createElement('li');
    li.className = 'item';
    li.innerHTML =
      '<span class="name"></span>' +
      '<span class="side"></span>' +
      '<span class="meta"></span>' +
      '<div class="bar" hidden><i></i></div>';
    li.querySelector('.name').textContent = it.file.name;
    it.el = li;
    setMeta(it, fmtSize(it.file.size) + ' · waiting');
    var side = li.querySelector('.side');
    var rm = document.createElement('button');
    rm.type = 'button';
    rm.className = 'btn ghost small';
    rm.textContent = 'Remove';
    rm.addEventListener('click', function () { removeItem(it); });
    side.appendChild(rm);
    it.removeBtn = rm;
    return li;
  }

  function setMeta(it, text, cls) {
    var m = it.el.querySelector('.meta');
    m.textContent = text;
    m.className = 'meta' + (cls ? ' ' + cls : '');
  }

  function setProgress(it, frac) {
    var bar = it.el.querySelector('.bar');
    bar.hidden = false;
    bar.firstElementChild.style.width = Math.max(0, Math.min(100, frac * 100)).toFixed(1) + '%';
  }

  function removeItem(it) {
    if (it === currentItem) { cancelConversion(); return; }
    if (it.url) URL.revokeObjectURL(it.url);
    it.el.remove();
    items = items.filter(function (x) { return x !== it; });
    refreshHead();
  }

  function refreshHead() {
    queueHead.hidden = items.length === 0;
    var pending = items.some(function (i) { return i.state === 'ready' || i.state === 'error'; });
    convertBtn.disabled = running || !pending;
    clearBtn.disabled = running;
  }

  /* ---------- engine ---------- */

  function loadEngine() {
    if (ffmpeg) return Promise.resolve(ffmpeg);
    if (loading) return loading;
    if (!FFmpeg) return Promise.reject(new Error('The converter library did not load. Open the site through a web server, not by double-clicking the file.'));
    setEngine('Loading converter engine…');
    var inst = new FFmpeg();
    inst.on('progress', function (e) {
      if (currentItem && isFinite(e.progress)) {
        setProgress(currentItem, e.progress);
        setMeta(currentItem, 'Converting · ' + Math.round(Math.max(0, Math.min(1, e.progress)) * 100) + '%');
      }
    });
    inst.on('log', function (e) {
      if (currentItem) {
        currentItem.log = (currentItem.log || '') + e.message + '\n';
        if (currentItem.log.length > 6000) currentItem.log = currentItem.log.slice(-4000);
      }
    });
    var base = new URL('vendor/', location.href).href;
    loading = inst.load({
      coreURL: base + 'ffmpeg-core.js',
      wasmURL: base + 'ffmpeg-core.wasm'
    }).then(function () {
      ffmpeg = inst;
      loading = null;
      setEngine('Converter engine ready. Processing happens on this device.');
      return inst;
    }).catch(function (err) {
      loading = null;
      throw err;
    });
    return loading;
  }

  /* ---------- conversion ---------- */

  async function convertOne(it) {
    currentItem = it;
    it.log = '';
    it.state = 'working';
    it.removeBtn.textContent = 'Cancel';
    setMeta(it, 'Preparing…');
    setProgress(it, 0);

    var crf = $('quality').value, preset = $('speed').value, ab = $('audio').value;
    var inName = 'in_' + it.id + '.wmv';
    var outName = 'out_' + it.id + '.mp4';

    try {
      var ff = await loadEngine();
      await ff.writeFile(inName, await fetchFile(it.file));
      var code = await ff.exec([
        '-i', inName,
        '-c:v', 'libx264', '-preset', preset, '-crf', crf,
        '-pix_fmt', 'yuv420p',
        '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2',
        '-c:a', 'aac', '-b:a', ab,
        '-movflags', '+faststart',
        outName
      ]);
      if (code !== 0) throw new Error('ffmpeg exited with code ' + code);
      var data = await ff.readFile(outName);
      var blob = new Blob([data.buffer], { type: 'video/mp4' });
      it.url = URL.createObjectURL(blob);
      it.state = 'done';
      setProgress(it, 1);
      setMeta(it, 'Done · ' + fmtSize(blob.size), 'ok');
      showDownload(it);
    } catch (err) {
      if (cancelled) {
        it.state = 'ready';
        setMeta(it, fmtSize(it.file.size) + ' · cancelled');
      } else {
        it.state = 'error';
        var hint = /memory|abort|OOM/i.test(String(err && err.message) + it.log)
          ? 'Ran out of memory. Try a smaller file.'
          : 'Could not convert this file. It may be damaged or use an unsupported codec.';
        setMeta(it, hint, 'err');
        if (window.console) console.error(err, it.log);
      }
      it.el.querySelector('.bar').hidden = true;
    } finally {
      try { if (ffmpeg) { await ffmpeg.deleteFile(inName); await ffmpeg.deleteFile(outName); } } catch (e) { /* files may not exist */ }
      it.removeBtn.textContent = 'Remove';
      currentItem = null;
    }
  }

  function showDownload(it) {
    var side = it.el.querySelector('.side');
    var a = document.createElement('a');
    a.className = 'btn primary small';
    a.href = it.url;
    a.download = it.file.name.replace(/\.(wmv|asf)$/i, '') + '.mp4';
    a.textContent = 'Download MP4';
    side.insertBefore(a, side.firstChild);
  }

  async function convertAll() {
    if (running) return;
    running = true;
    cancelled = false;
    refreshHead();
    var todo = items.filter(function (i) { return i.state === 'ready' || i.state === 'error'; });
    for (var k = 0; k < todo.length; k++) {
      if (cancelled) break;
      if (items.indexOf(todo[k]) === -1) continue;
      try { await convertOne(todo[k]); }
      catch (e) { /* handled in convertOne */ }
      if (!ffmpeg && !loading && todo[k].state === 'error') {
        setEngine('The converter engine could not start. Check your connection and reload.', true);
        break;
      }
    }
    running = false;
    refreshHead();
  }

  function cancelConversion() {
    cancelled = true;
    if (ffmpeg) {
      ffmpeg.terminate();
      ffmpeg = null;
      setEngine('Cancelled. The engine restarts on the next conversion.');
    }
  }

  /* ---------- events ---------- */

  $('browse').addEventListener('click', function () { fileInput.click(); });
  drop.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fileInput.click(); }
  });
  fileInput.addEventListener('change', function () { addFiles(fileInput.files); fileInput.value = ''; });

  ['dragenter', 'dragover'].forEach(function (t) {
    drop.addEventListener(t, function (e) { e.preventDefault(); drop.classList.add('over'); });
  });
  ['dragleave', 'drop'].forEach(function (t) {
    drop.addEventListener(t, function (e) { e.preventDefault(); drop.classList.remove('over'); });
  });
  drop.addEventListener('drop', function (e) { if (e.dataTransfer) addFiles(e.dataTransfer.files); });
  window.addEventListener('dragover', function (e) { e.preventDefault(); });
  window.addEventListener('drop', function (e) { e.preventDefault(); });

  convertBtn.addEventListener('click', convertAll);
  clearBtn.addEventListener('click', function () {
    items.forEach(function (i) { if (i.url) URL.revokeObjectURL(i.url); });
    items = [];
    queueEl.innerHTML = '';
    refreshHead();
  });

  refreshHead();
})();
